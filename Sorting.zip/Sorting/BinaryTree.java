import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A normal, non-self-balancing binary tree.
 *
 * @author Annli
 * @version 3/3/20
 */
public class BinaryTree
{
    private Node root;

    public BinaryTree() // constructor without root
    {
        root = null;
    }

    public BinaryTree(Node r) // constructor with root
    {
        root = r;
    }

    public Node getRoot() // returns root
    {
        return root;
    }

    private void addNode(int value, Node start) // private recursive function for adding node
    {
        Node n = new Node(value);
        if (n.getValue() < start.getValue())
        {
            if (start.getLeft() == null)
            {
                start.setLeft(n);
                n.setParent(start);
                return;
            }
            addNode(value, start.getLeft());
        }
        else
        {
            if (start.getRight() == null)
            {
                start.setRight(n);
                n.setParent(start);
                return;
            }
            addNode(value, start.getRight());
        }
    }

    public void addNode(int value) // Given a value, adds node to tree.
    {
        Node n = new Node(value);
        if (root == null)
        {
            root = n;
            return;
        }
        addNode(value, root);
    }

    public int getMin() // returns minimum value in tree
    {
        if (root == null)
        {
            System.out.println("TREE IS NULL");
            return 0;
        }
        Node n = root;
        while (n.getLeft() != null)
        {
            n = n.getLeft();
        }
        return n.getValue();
    }

    public int getMax() // returns maximum value in tree
    {
        if (root == null)
        {
            System.out.println("TREE IS NULL");
            return 0;
        }
        Node n = root;
        while (n.getRight() != null)
        {
            n = n.getRight();
        }
        return n.getValue();
    }

    private int getHeight(Node start) // private function for finding height
    {
        if (start == null)
        {
            return 0;
        }
        return Math.max(getHeight(start.getLeft()), getHeight(start.getRight())) + 1;
    }

    public int getHeight() // returns the maximum height of the tree
    {
        if (root == null)
        {
            return 0;
        }
        return Math.max(getHeight(root.getLeft()), getHeight(root.getRight())) + 1;
    }

    private void print(Node n) // private recursive function for printing
    {
        if (n == null)
        {
            return;
        }
        print(n.getLeft());
        // System.out.print(n.getValue() + " ");
        print(n.getRight());
    }

    public void printTree() // print the tree as a sorted list
    {
        print(root);
        System.out.println();
    }

    private void toArrayList(ArrayList<Integer> a, Node n) // private function for mapping tree to ArrayList
    {
        if (n == null)
        {
            return;
        }
        toArrayList(a, n.getLeft());
        a.add(n.getValue());
        toArrayList(a, n.getRight());
    }
    
    public ArrayList<Integer> toArrayList() // returns values of tree in a sorted ArrayList
    {
        ArrayList<Integer> a = new ArrayList<>();
        toArrayList(a, root);
        return a;
    }
    
    public void sort(int[] a) // PRECONDITION: TREE INITIALLY HAS NO NODES - THIS IS VERY IMPORTANT
    {
        if (root != null)
        {
            return;
        }
        for (int i = 0; i < a.length; i++)
        {
            addNode(a[i]);
        }
        ArrayList<Integer> treeList = toArrayList();
        for (int i = 0; i < a.length; i++)
        {
            a[i] = treeList.get(i);
        }
    }

    public static void main(String[] args) // testing how much time it takes to run insert and findmin
    {
        Random rand = new Random();
        int numberNodes = 100000; // I changed this variable to test different numbers of nodes
        int numberTimes = 1; // Test the average of this many times, changed based on how long it would take
        // (ie I can't repeat 1,000,000 nodes 1,000 times, that would take too long) 

        /**                        
        // ********** RANDOMLY GENERATED NODES - should work in O(log n) time

        int insert = 0;
        int min = 0;
        for (int j = 0; j < numberTimes; j++)
        {
            //System.out.println("***");
            BinaryTree tree = new BinaryTree();
            for (int i = 0; i < numberNodes-1; i++)
            {
                tree.addNode(rand.nextInt());
            }
            int n = rand.nextInt();
            long start1 = System.nanoTime(); // code for measuring time comes from https://www.techiedelight.com/measure-elapsed-time-execution-time-java/
            tree.addNode(n);
            long end1 = System.nanoTime();
            //System.out.println("Time taken to insert the " + numberNodes + "th node is: " + (end1-start1) + " ns");
            insert += (end1-start1);

            long start2 = System.nanoTime();
            int m = tree.getMin();
            long end2 = System.nanoTime();
            //System.out.println("Time taken to find minimum is: " + (end2-start2) + " ns");
            min += (end2-start2);
        }

        System.out.println("***\nOn average, it took " + insert/numberTimes + " ns to insert nth node and " + min/numberTimes + " ns to find min");



        // ********** WORST-CASE NODES - should work in O(n) time

        int worstInsert = 0;
        int worstMin = 0;
        for (int j = 0; j < numberTimes; j++)
        {
            //System.out.println("***");
            BinaryTree tree = new BinaryTree();
            for (int i = 0; i < numberNodes-1; i++)
            {
                tree.addNode(numberNodes-i);
            }
            long start1 = System.nanoTime();
            tree.addNode(0);
            long end1 = System.nanoTime();
            //System.out.println("Time taken to insert the " + numberNodes + "th node is: " + (end1-start1) + " ns");
            worstInsert += (end1-start1);

            long start2 = System.nanoTime();
            int m = tree.getMin();
            long end2 = System.nanoTime();
            //System.out.println("Time taken to find minimum is: " + (end2-start2) + " ns");
            worstMin += (end2-start2);
        }

        System.out.println("***\nOn average, it took " + worstInsert/numberTimes + " ns to insert nth node and " + worstMin/numberTimes + " ns to find min");
        **/

        // ********** SORTING

        // Create random array
        int[] a = new int[numberNodes];
        for (int i = 0; i < a.length; i++)
        {
            //a[i] = rand.nextInt();
            //a[i] = i;
            a[i] = numberNodes-i;
        }

        // Insert and sort in tree
        long start1 = System.nanoTime();
        BinaryTree tree = new BinaryTree();
        tree.sort(a);
        long end1 = System.nanoTime();
        
        // Sort with Java's program
        long start2 = System.nanoTime();
        Arrays.sort(a);
        long end2 = System.nanoTime();
        
        System.out.println("Tree took " + (end1-start1) + " ns while Java took " + (end2-start2) + " ns to sort");
    }
}
