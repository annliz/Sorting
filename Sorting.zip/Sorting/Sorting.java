/**
 * Insert Sort and Counting Sort.
 *
 * @author Annli
 * @version 2/13/20
 */
public class Sorting
{
    public Sorting()
    {
    }

    public static void insertionSort(int[] a)
    {
        for (int i = 1; i < a.length; i++)
        {
            int x = a[i];
            int j = i-1;
            while (j >= 0 && a[j] > x)
            {
                a[j+1] = a[j];
                a[j] = x;
                j--;
            }
        }
    }

    public static void countingSort(int[] a)
    {
        int min = a[0];
        int max = a[0];
        for (int i = 0; i < a.length; i++)
        {
            if (a[i] < min)
            {
                min = a[i];
            }
            else if (a[i] > max)
            {
                max = a[i];
            }
        }
        int[] counter = new int[max-min+1];
        for (int i = 0; i < a.length; i++)
        {
            counter[a[i] - min]++;
        }
        int index = 0;
        for (int i = 0; i < counter.length; i++)
        {
            for (int j = 0; j < counter[i]; j++)
            {
                a[index] = i + min;
                index++;
            }
        }
    }
    
    public static void main(String[] args)
    {
        int[] a = {71, 6, -5, 444, 2, -10, -2, -33333, 0};
        countingSort(a);
        for (int i = 0; i < a.length; i++)
        {
            System.out.println(a[i]);
        }
    }
}
